
import './App.css';
import Carrossel from './components/Carrossel';

function App() {

  return (
    <Carrossel />
  );
}

export default App;
